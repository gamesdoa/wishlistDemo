/**
 * Soon javadoc will get generated here proper.
 */
package com.sample.wishlistDemo.api.generated;
